import { Product, User } from './interfaces';

export async function fetchProducts(): Promise<Product[]> {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve([
                { id: 1, name: 'Product 1', price: 100, stock: 10 },
                { id: 2, name: 'Product 2', price: 200, stock: 5 },
            ]);
        }, 1000);
    });
}

export async function fetchUsers(): Promise<User[]> {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve([
                { id: 1, name: 'User 1', email: 'user1@example.com' },
                { id: 2, name: 'User 2', email: 'user2@example.com' },
            ]);
        }, 1000);
    });
}
