interface IRepository<T> {
    add(entity: T): void;
    update(id: number, entity: Partial<T>): void;
    delete(id: number): void;
    getById(id: number): T | undefined;
    getAll(): T[];
}

class Repository<T extends { id: number }> implements IRepository<T> {
    private entities: T[] = [];

    add(entity: T): void {
        this.entities.push(entity);
    }

    update(id: number, entity: Partial<T>): void {
        const index = this.entities.findIndex(e => e.id === id);
        if (index !== -1) {
            this.entities[index] = { ...this.entities[index], ...entity };
        }
    }

    delete(id: number): void {
        this.entities = this.entities.filter(e => e.id !== id);
    }

    getById(id: number): T | undefined {
        return this.entities.find(e => e.id === id);
    }

    getAll(): T[] {
        return this.entities;
    }
}

export { Repository, IRepository };
