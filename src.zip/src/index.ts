import { orderService } from './orderService';
import { Product } from './interfaces';
import { addProduct, updateProduct, deleteProduct, fetchProducts } from './productService';
import { addUser, fetchUsers } from './userService';
import { User } from './userService';

async function main() {
    console.log('Fetching initial Products...');
    const initialProducts = await fetchProducts();
    console.log('Initial Products:', initialProducts);

    const product1: Product = { id: 1, name: 'shirt', price: 5000, stock: 5 };
    const product2: Product = { id: 2, name: 'trouser', price: 3500, stock: 10 };
    const product3: Product = { id: 3, name: 'dupatta', price: 2500, stock: 10 };
    const product4: Product = { id: 4, name: 'slipper', price: 4500, stock: 10 };

    console.log('Adding Products...');
    addProduct(product1);
    addProduct(product2);
    addProduct(product3);
    addProduct(product4);

    console.log('Fetching Products after adding...');
    const productsAfterAdding = await fetchProducts();
    console.log('Products after Adding:', productsAfterAdding);

    console.log('Updating Product 1...');
    updateProduct(1, { price: 1100, stock: 4 });

    console.log('Fetching Products after updating...');
    const productsAfterUpdating = await fetchProducts();
    console.log('Products after Updating:', productsAfterUpdating);

    console.log('Creating an order...');
    const order = orderService.addOrder({ userId: 1, products: [], totalAmount: 0 });

    console.log('Adding items to the order...');
    orderService.addItemToOrder(order.id, product1);
    orderService.addItemToOrder(order.id, product2);
    orderService.addItemToOrder(order.id, product3);
    orderService.addItemToOrder(order.id, product4);

    console.log('Checking out the order...');
    orderService.checkout(order.id);

    console.log('Deleting Product 2...');
    deleteProduct(2);

    console.log('Fetching Products after deleting...');
    const productsAfterDeleting = await fetchProducts();
    console.log('Products after Deleting:', productsAfterDeleting);

    console.log('Adding a User...');
    const user: User = { id: 1, name: 'Kainat Karim', email: 'kainat.karim@example.com' };
    addUser(user);

    console.log('Fetching Users after adding...');
    const users = await fetchUsers();
    console.log('Users:', users);
}

main();
