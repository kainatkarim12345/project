import { Order, Product } from './interfaces';
import { LogMethod } from './decorators';

class OrderService {
    private orders: Order[] = [];
    private static nextId = 1;

    @LogMethod
    addOrder(order: Omit<Order, 'id'>): Order {
        const newOrder = { ...order, id: OrderService.nextId++ };
        this.orders.push(newOrder);
        return newOrder;
    }

    getOrderById(id: number): Order | undefined {
        return this.orders.find(order => order.id === id);
    }

    @LogMethod
    addItemToOrder(orderId: number, product: Product): void {
        const order = this.getOrderById(orderId);
        if (!order) {
            throw new Error(`Order with id ${orderId} not found`);
        }
        order.products.push(product);
        order.totalAmount += product.price;
    }

    @LogMethod
    checkout(orderId: number): void {
        const order = this.getOrderById(orderId);
        if (!order) {
            throw new Error(`Order with id ${orderId} not found`);
        }
        console.log('Order checked out:', order);
    }
}

export const orderService = new OrderService();
