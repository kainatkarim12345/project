import { Product } from './interfaces';

let products: Product[] = [];

export function addProduct(product: Product): void {
    products.push(product);
}

export function updateProduct(id: number, updatedProduct: Partial<Product>): void {
    const productIndex = products.findIndex(p => p.id === id);
    if (productIndex !== -1) {
        products[productIndex] = { ...products[productIndex], ...updatedProduct };
    }
}

export function deleteProduct(id: number): void {
    products = products.filter(p => p.id !== id);
}

export function getAllProducts(): Product[] {
    return products;
}

export async function fetchProducts(): Promise<Product[]> {
    // Simulate asynchronous fetch operation, e.g., from a database
    return new Promise<Product[]>((resolve, reject) => {
        setTimeout(() => {
            resolve(products);
        }, 1000); // Simulate delay of 1 second
    });
}
