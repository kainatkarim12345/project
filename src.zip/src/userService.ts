export interface User {
    id: number;
    name: string;
    email: string;
}

let users: User[] = [];

export function addUser(user: User): void {
    users.push(user);
}

export function updateUser(id: number, updatedUser: Partial<User>): void {
    const userIndex = users.findIndex(u => u.id === id);
    if (userIndex !== -1) {
        users[userIndex] = { ...users[userIndex], ...updatedUser };
    }
}

export function deleteUser(id: number): void {
    users = users.filter(u => u.id !== id);
}

export function getAllUsers(): User[] {
    return users;
}

export async function fetchUsers(): Promise<User[]> {
    // Simulate asynchronous fetch operation, e.g., from a database
    return new Promise<User[]>((resolve, reject) => {
        setTimeout(() => {
            resolve(users);
        }, 1000); // Simulate delay of 1 second
    });
}
