export interface Product {
    id: number;
    name: string;
    price: number;
    stock: number;
}

export interface User {
    id: number;
    name: string;
    email: string;
}

export interface Order {
    id: number;
    userId: number;
    products: Product[];
    totalAmount: number;
}
